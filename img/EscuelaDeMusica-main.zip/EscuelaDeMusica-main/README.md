# Escuela De Música
 ## Descripción
### clases
**clases de los distintos instrumentos**
*grupales o individual*

### instrumentos populares 
* guitarras
* mandolinas
* piano
  **venta de instrumentos o accesorios**
### deportes
1. puas
2. cuerdas
3. afinadores
4. talis
5. capo
6. estuche

## Objetivo del proyecto

### Usar HTML 5 en VS Code para crear la página

* Promocionar los instrumentos musicales
* Dar a conocer el servicio de la tienda
* Usar imágenes para mostrar e establecimiento con `<img src="">.`
* Crear tablas para mostrar información de los productos con `<table> </table>.`
* Usar links y referencias para repartir más información


## Ubicación

  **https://maps.app.goo.gl/X38oaY52wurMH9Gr5**

  
